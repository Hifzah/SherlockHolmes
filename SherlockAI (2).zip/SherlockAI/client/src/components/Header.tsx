import { useState } from 'react';
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { MenuIcon, Award, BookOpen, HelpCircle, FileText } from 'lucide-react';
import { 
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function Header() {
  const [location] = useLocation();
  
  return (
    <header className="bg-sherlock-primary text-white p-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/">
          <div className="flex items-center cursor-pointer">
            {/* Magnifying glass icon representing detective work */}
            <div className="w-10 h-10 rounded-full mr-3 bg-white/80 p-1 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-sherlock-primary">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                <line x1="11" y1="8" x2="11" y2="14"></line>
                <line x1="8" y1="11" x2="14" y2="11"></line>
              </svg>
            </div>
            <h1 className="font-playfair text-2xl md:text-3xl font-bold tracking-wider">Sherlock Holmes AI</h1>
          </div>
        </Link>
        
        <div className="hidden md:flex items-center space-x-3">
          <Link href="/">
            <Button 
              variant="outline" 
              className={`${location === '/' ? 'bg-sherlock-accent' : 'bg-sherlock-secondary'} text-white border-sherlock-accent vintage-button hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide`}
            >
              <BookOpen className="h-4 w-4 mr-2" />
              Consultations
            </Button>
          </Link>
          
          <Link href="/casefiles">
            <Button 
              variant="outline" 
              className={`${location === '/casefiles' ? 'bg-sherlock-accent' : 'bg-sherlock-secondary'} text-white border-sherlock-accent vintage-button hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide`}
            >
              <FileText className="h-4 w-4 mr-2" />
              Case Files
            </Button>
          </Link>
          
          <Link href="/dashboard">
            <Button 
              variant="outline" 
              className={`${location === '/dashboard' ? 'bg-sherlock-accent' : 'bg-sherlock-secondary'} text-white border-sherlock-accent vintage-button hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide`}
            >
              <Award className="h-4 w-4 mr-2" />
              Detective Rank
            </Button>
          </Link>
          
          <Button variant="outline" className="bg-sherlock-secondary text-white border-sherlock-accent vintage-button hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide">
            <HelpCircle className="h-4 w-4 mr-2" />
            Help
          </Button>
        </div>
        
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden text-white">
              <MenuIcon className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent className="bg-sherlock-primary text-white border-sherlock-secondary">
            <div className="flex flex-col space-y-4 mt-8">
              <Link href="/">
                <Button 
                  variant="outline" 
                  className={`w-full ${location === '/' ? 'bg-sherlock-accent' : 'bg-sherlock-secondary'} text-white border-sherlock-accent hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide`}
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  Consultations
                </Button>
              </Link>
              
              <Link href="/casefiles">
                <Button 
                  variant="outline" 
                  className={`w-full ${location === '/casefiles' ? 'bg-sherlock-accent' : 'bg-sherlock-secondary'} text-white border-sherlock-accent hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide`}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Case Files
                </Button>
              </Link>
              
              <Link href="/dashboard">
                <Button 
                  variant="outline" 
                  className={`w-full ${location === '/dashboard' ? 'bg-sherlock-accent' : 'bg-sherlock-secondary'} text-white border-sherlock-accent hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide`}
                >
                  <Award className="h-4 w-4 mr-2" />
                  Detective Rank
                </Button>
              </Link>
              
              <Button variant="outline" className="w-full bg-sherlock-secondary text-white border-sherlock-accent hover:bg-sherlock-accent transition-colors font-special text-sm tracking-wide">
                <HelpCircle className="h-4 w-4 mr-2" />
                Help
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
