import { cn } from "@/lib/utils";

interface SpinnerProps {
  className?: string;
}

export function Spinner({ className }: SpinnerProps) {
  return (
    <div
      className={cn(
        "animate-spin rounded-full border-4 border-solid border-sherlock-secondary border-t-transparent h-6 w-6",
        className
      )}
    />
  );
}
