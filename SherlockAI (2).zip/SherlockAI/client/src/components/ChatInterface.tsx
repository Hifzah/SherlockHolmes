import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Send } from "lucide-react";
import { Message } from "@/lib/types";
import ChatMessage from "@/components/ChatMessage";
import { useSpeech } from "@/hooks/useSpeech";
import { Spinner } from "@/components/ui/spinner";

interface ChatInterfaceProps {
  messages: Message[];
  onSendMessage: (message: string) => void;
  loading: boolean;
}

export default function ChatInterface({ messages, onSendMessage, loading }: ChatInterfaceProps) {
  const [inputValue, setInputValue] = useState("");
  const [isListening, setIsListening] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  
  const { startListening, stopListening, transcript, isSupported } = useSpeech();
  
  // Update input field when transcript changes
  useEffect(() => {
    if (transcript) {
      setInputValue(transcript);
    }
  }, [transcript]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);
  
  const handleSendMessage = () => {
    if (inputValue.trim()) {
      onSendMessage(inputValue);
      setInputValue("");
    }
  };
  
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };
  
  const toggleListening = () => {
    if (isListening) {
      stopListening();
      setIsListening(false);
    } else {
      startListening();
      setIsListening(true);
    }
  };
  
  return (
    <div className="w-full md:w-3/4 flex flex-col bg-sherlock-lightBg shadow-lg rounded-lg paper-bg" style={{ minHeight: "70vh" }}>
      <div className="flex-grow p-4 overflow-auto" ref={chatContainerRef}>
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
        
        {loading && (
          <div className="flex justify-center my-4">
            <Spinner className="h-8 w-8 text-sherlock-secondary" />
          </div>
        )}
      </div>
      
      <div className="p-4 border-t border-gray-300 bg-white/70 rounded-b-lg">
        <div className="flex items-center">
          <div className="relative flex-grow">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message or mystery..."
              className="w-full border-2 border-sherlock-secondary rounded-lg py-6 px-4 pr-12 font-lora focus:outline-none focus:ring-2 focus:ring-sherlock-accent"
              disabled={loading}
            />
            {isSupported && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={toggleListening}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sherlock-secondary hover:text-sherlock-accent transition-colors"
                disabled={loading}
              >
                {isListening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </Button>
            )}
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={loading || !inputValue.trim()}
            className="ml-3 bg-sherlock-primary text-white px-6 py-6 rounded-lg hover:bg-sherlock-accent transition-colors font-special tracking-wide vintage-button"
          >
            <Send className="h-5 w-5 mr-2" />
            Send
          </Button>
        </div>
        
        {isListening && (
          <div className="mt-2 text-center text-sherlock-accent font-special">
            Listening... <span className="animate-pulse">●</span>
          </div>
        )}
      </div>
    </div>
  );
}
