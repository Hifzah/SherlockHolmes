import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Folder, FolderOpen, PlusCircle, History, Archive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

interface SidePanelProps {
  onSelectCase: (caseName: string) => void;
  selectedCase: string | null;
  chatHistory: { id: string; title: string; date: string }[];
  onStartNewChat: () => void;
  onSelectChatHistory: (chatId: string) => void;
  selectedChatId: string | null;
}

export default function SidePanel({ 
  onSelectCase, 
  selectedCase, 
  chatHistory = [], 
  onStartNewChat = () => {}, 
  onSelectChatHistory = () => {},
  selectedChatId = null
}: SidePanelProps) {
  const cases = [
    "The Missing Heirloom",
    "The Baker Street Burglary",
    "The Strange Case of Dr. Watson"
  ];
  
  const evidenceItems = [
    { name: "Magnifying Glass", image: "/magnifying-glass.svg" },
    { name: "Pocket Watch", image: "/pocket-watch.svg" },
    { name: "Footprint Cast", image: "/footprint.svg" },
    { name: "Mysterious Key", image: "/key.svg" }
  ];
  
  return (
    <div className="w-full md:w-1/4 flex flex-col gap-4 overflow-y-auto">
      {/* New Consultation button */}
      <Button 
        onClick={onStartNewChat}
        className="w-full bg-sherlock-secondary hover:bg-sherlock-accent text-white mb-1 font-special tracking-wide vintage-button"
      >
        <PlusCircle className="w-4 h-4 mr-2" />
        New Consultation
      </Button>
      
      {/* Chat History panel */}
      <Card className="bg-sherlock-lightBg shadow-lg rounded-lg paper-bg border-0">
        <CardHeader className="pb-2">
          <CardTitle className="font-playfair text-xl font-bold text-sherlock-primary border-b-2 border-sherlock-secondary pb-2 flex items-center">
            <History className="w-5 h-5 mr-2 text-sherlock-secondary" />
            Previous Consultations
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ScrollArea className="h-[150px] pr-4">
            {chatHistory.length > 0 ? (
              <ul className="space-y-2">
                {chatHistory.map((chat) => (
                  <li 
                    key={chat.id}
                    className={`p-2 hover:bg-white/50 rounded cursor-pointer transition-colors ${selectedChatId === chat.id ? 'bg-white/50' : ''}`}
                    onClick={() => onSelectChatHistory(chat.id)}
                  >
                    <Archive className="inline-block text-sherlock-secondary mr-2 h-4 w-4" />
                    <span className="font-special text-sm">{chat.title}</span>
                    <div className="text-xs text-gray-500 ml-6">{chat.date}</div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-center p-4 text-gray-500 italic">
                No previous consultations
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Case files panel */}
      <Card className="bg-sherlock-lightBg shadow-lg rounded-lg paper-bg border-0">
        <CardHeader className="pb-2">
          <CardTitle className="font-playfair text-xl font-bold text-sherlock-primary border-b-2 border-sherlock-secondary pb-2">
            Case Files
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ul className="space-y-2">
            {cases.map((caseName) => (
              <li 
                key={caseName}
                className={`p-2 hover:bg-white/50 rounded cursor-pointer transition-colors ${selectedCase === caseName ? 'bg-white/50' : ''}`}
                onClick={() => onSelectCase(caseName)}
              >
                {selectedCase === caseName ? (
                  <FolderOpen className="inline-block text-sherlock-secondary mr-2 h-4 w-4" />
                ) : (
                  <Folder className="inline-block text-sherlock-secondary mr-2 h-4 w-4" />
                )}
                <span className="font-special">{caseName}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Evidence collection panel */}
      <Card className="bg-sherlock-lightBg shadow-lg rounded-lg paper-bg border-0">
        <CardHeader className="pb-2">
          <CardTitle className="font-playfair text-xl font-bold text-sherlock-primary border-b-2 border-sherlock-secondary pb-2">
            Evidence Collection
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 gap-2">
            {evidenceItems.map((item) => (
              <div key={item.name} className="bg-white/70 p-2 rounded shadow-sm">
                <div className="w-full aspect-square bg-gray-100 rounded flex items-center justify-center">
                  <svg className="w-full h-full p-4 text-sherlock-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    {item.name === "Magnifying Glass" && (
                      <>
                        <circle cx="10" cy="10" r="7"></circle>
                        <line x1="21" y1="21" x2="15" y2="15"></line>
                      </>
                    )}
                    {item.name === "Pocket Watch" && (
                      <>
                        <circle cx="12" cy="12" r="10"></circle>
                        <circle cx="12" cy="12" r="1"></circle>
                        <polyline points="12 6 12 12"></polyline>
                      </>
                    )}
                    {item.name === "Footprint Cast" && (
                      <>
                        <path d="M7 5.5C7 7 5.5 8 5.5 10S7 14 7 15.5C7 17 5.5 18 5.5 20H14.5C14.5 18 16 17 16 15.5C16 14 14.5 13 14.5 11C14.5 9 16 8 16 6.5C16 5 14.5 4 14.5 2H5.5C5.5 4 7 5 7 5.5Z"></path>
                      </>
                    )}
                    {item.name === "Mysterious Key" && (
                      <>
                        <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path>
                      </>
                    )}
                  </svg>
                </div>
                <p className="text-xs mt-1 font-special text-center">{item.name}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Victorian London scenery */}
      <Card className="bg-sherlock-lightBg shadow-lg rounded-lg overflow-hidden border-0">
        <div className="w-full aspect-video bg-sherlock-primary/20 relative flex items-center justify-center">
          <svg className="w-full h-full p-4 text-sherlock-primary/30" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10,80 L20,80 L20,70 L30,70 L30,80 L40,80 L40,60 L50,50 L60,60 L60,80 L70,80 L70,70 L80,70 L80,80 L90,80 L90,30 L10,30 Z" stroke="currentColor" strokeWidth="2" fill="none" />
            <path d="M25,70 L25,65 L35,65 L35,70" stroke="currentColor" strokeWidth="1" />
            <path d="M65,70 L65,65 L75,65 L75,70" stroke="currentColor" strokeWidth="1" />
            <path d="M45,80 L45,70 L55,70 L55,80" stroke="currentColor" strokeWidth="1" />
            <path d="M10,30 L50,10 L90,30" stroke="currentColor" strokeWidth="2" />
            <circle cx="20" cy="40" r="3" stroke="currentColor" strokeWidth="1" />
            <circle cx="40" cy="40" r="3" stroke="currentColor" strokeWidth="1" />
            <circle cx="60" cy="40" r="3" stroke="currentColor" strokeWidth="1" />
            <circle cx="80" cy="40" r="3" stroke="currentColor" strokeWidth="1" />
          </svg>
        </div>
        <div className="p-3 text-center font-special text-sm text-sherlock-primary">
          The streets of London, 1895
        </div>
      </Card>
    </div>
  );
}
