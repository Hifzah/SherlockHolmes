import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent, 
  CardFooter 
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

// Custom hook for local storage
function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  // State to store our value
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === "undefined") {
      return initialValue;
    }
    try {
      // Get from local storage by key
      const item = window.localStorage.getItem(key);
      // Parse stored json or if none return initialValue
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      // If error also return initialValue
      console.log(error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter function that
  // persists the new value to localStorage.
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Allow value to be a function so we have same API as useState
      const valueToStore =
        value instanceof Function ? value(storedValue) : value;
      // Save state
      setStoredValue(valueToStore);
      // Save to local storage
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      // A more advanced implementation would handle the error case
      console.log(error);
    }
  };

  return [storedValue, setValue];
}

type UserRank = {
  id: number;
  userId: number | null;
  guestId: string | null;
  rankLevel: string;
  rankPoints: number;
  questionsAsked: number;
  logicalQuestionsAsked: number;
  mysteriesSolved: number;
  cluesAnalyzed: number;
  createdAt: string;
  updatedAt: string;
  rankTitle: string;
  rankDescription: string;
  nextRankTitle: string;
  nextRankPoints: number;
  progressPercent: number;
}

type Achievement = {
  id: number;
  name: string;
  description: string;
  badgeIcon: string;
  pointsAwarded: number;
  awardedAt: string;
}

type UserStats = {
  questionsAsked: number;
  logicalQuestionsAsked: number;
  mysteriesSolved: number;
  cluesAnalyzed: number;
  pointsToNextRank: number;
}

export default function DetectiveDashboard() {
  const { toast } = useToast();
  const [guestId, setGuestId] = useLocalStorage<string>("sherlock-guest-id", "");
  
  // Generate a guest ID if none exists
  useEffect(() => {
    if (!guestId) {
      const newGuestId = crypto.randomUUID();
      setGuestId(newGuestId);
    }
  }, [guestId, setGuestId]);
  
  // Fetch user rank data
  const { 
    data: rankData,
    isLoading,
    isError,
    error,
    refetch
  } = useQuery({
    queryKey: [`/api/ranks/${guestId}`],
    queryFn: async () => {
      if (!guestId) return null;
      try {
        return await apiRequest(`/api/ranks/${guestId}`);
      } catch (error) {
        console.error("Failed to fetch rank data:", error);
        toast({
          title: "Error fetching rank data",
          description: "There was a problem connecting to Baker Street. Please try again.",
          variant: "destructive"
        });
        return null;
      }
    },
    enabled: !!guestId
  });
  
  const userRank = rankData?.userRank as UserRank | undefined;
  const achievements = rankData?.achievements as Achievement[] | undefined;
  const stats = rankData?.stats as UserStats | undefined;
  
  return (
    <div className="flex flex-col min-h-screen bg-sherlock-background">
      <Header />
      
      <main className="flex-grow container mx-auto p-4">
        <h1 className="text-3xl font-bold font-playfair text-sherlock-primary mb-8 flex items-center">
          <span className="mr-2">Detective Dashboard</span>
          {userRank && (
            <Badge className="bg-sherlock-secondary text-white ml-2">
              {userRank.rankLevel === "chief_investigator" && "🧠 "}
              {userRank.rankLevel === "inspector" && "🔍 "}
              {userRank.rankLevel === "newbie_detective" && "🕵️ "}
              {userRank.rankTitle}
            </Badge>
          )}
        </h1>
        
        {isLoading ? (
          <div className="text-center py-12">
            <p className="italic font-special text-lg">Consulting with Baker Street...</p>
          </div>
        ) : isError ? (
          <div className="text-center py-12">
            <p className="text-red-600 font-special text-lg">
              Failed to retrieve your detective records.
            </p>
            <button 
              onClick={() => refetch()}
              className="mt-4 px-4 py-2 bg-sherlock-secondary text-white rounded hover:bg-sherlock-accent transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Current Rank Card */}
            <Card className="bg-sherlock-lightBg paper-bg border-0 shadow-md order-1 md:order-1">
              <CardHeader className="border-b border-sherlock-secondary/20 pb-3">
                <CardTitle className="font-playfair">{userRank?.rankTitle}</CardTitle>
                <CardDescription className="font-special">{userRank?.rankDescription}</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-special">Detective Points</span>
                      <span className="text-sm font-mono font-bold">{userRank?.rankPoints}</span>
                    </div>
                    <Progress
                      value={userRank?.progressPercent || 0}
                      className="h-2 bg-gray-200"
                    />
                    {userRank?.nextRankTitle && (
                      <div className="text-xs text-right font-special">
                        {stats?.pointsToNextRank} points to {userRank.nextRankTitle}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-playfair font-semibold">Detective Statistics</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex justify-between items-center border-b border-dashed border-sherlock-secondary/20 pb-1">
                        <span className="font-special">Cases Consulted:</span>
                        <span className="font-mono">{stats?.questionsAsked || 0}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-dashed border-sherlock-secondary/20 pb-1">
                        <span className="font-special">Logical Deductions:</span>
                        <span className="font-mono">{stats?.logicalQuestionsAsked || 0}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-dashed border-sherlock-secondary/20 pb-1">
                        <span className="font-special">Mysteries Solved:</span>
                        <span className="font-mono">{stats?.mysteriesSolved || 0}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-dashed border-sherlock-secondary/20 pb-1">
                        <span className="font-special">Clues Analyzed:</span>
                        <span className="font-mono">{stats?.cluesAnalyzed || 0}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Rank Progression Card */}
            <Card className="bg-sherlock-lightBg paper-bg border-0 shadow-md order-3 md:order-2 md:col-span-2">
              <CardHeader className="border-b border-sherlock-secondary/20 pb-3">
                <CardTitle className="font-playfair">Detective Progression</CardTitle>
                <CardDescription className="font-special">
                  Your journey from amateur to master detective
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-8">
                  <div className="relative pt-6">
                    <div className="absolute left-3 top-0 h-full w-1 bg-sherlock-secondary/20"></div>
                    
                    <div className="relative pl-10 pb-8">
                      <div className={`absolute left-0 p-2 rounded-full ${userRank?.rankLevel === "newbie_detective" || userRank?.rankLevel === "inspector" || userRank?.rankLevel === "chief_investigator" ? "bg-sherlock-secondary text-white" : "bg-gray-200"}`}>
                        🕵️
                      </div>
                      <h3 className="font-playfair font-bold text-lg">Newbie Detective</h3>
                      <p className="font-special text-sm mt-1 mb-2">Just starting your journey into the world of deduction.</p>
                      <Badge variant={userRank?.rankLevel === "newbie_detective" ? "default" : "outline"} className="mt-1">
                        {userRank?.rankLevel === "newbie_detective" ? "Current Rank" : "Completed"}
                      </Badge>
                    </div>
                    
                    <div className="relative pl-10 pb-8">
                      <div className={`absolute left-0 p-2 rounded-full ${userRank?.rankLevel === "inspector" || userRank?.rankLevel === "chief_investigator" ? "bg-sherlock-secondary text-white" : "bg-gray-200"}`}>
                        🔍
                      </div>
                      <h3 className="font-playfair font-bold text-lg">Inspector</h3>
                      <p className="font-special text-sm mt-1 mb-2">Skilled at following evidence and uncovering hidden truths.</p>
                      <Badge variant={userRank?.rankLevel === "inspector" ? "default" : userRank?.rankLevel === "chief_investigator" ? "outline" : "secondary"} className="mt-1">
                        {userRank?.rankLevel === "inspector" ? "Current Rank" : userRank?.rankLevel === "chief_investigator" ? "Completed" : "Locked"}
                      </Badge>
                    </div>
                    
                    <div className="relative pl-10">
                      <div className={`absolute left-0 p-2 rounded-full ${userRank?.rankLevel === "chief_investigator" ? "bg-sherlock-secondary text-white" : "bg-gray-200"}`}>
                        🧠
                      </div>
                      <h3 className="font-playfair font-bold text-lg">Chief Investigator</h3>
                      <p className="font-special text-sm mt-1 mb-2">A master of logic and deduction, rivaling Holmes himself.</p>
                      <Badge variant={userRank?.rankLevel === "chief_investigator" ? "default" : "secondary"} className="mt-1">
                        {userRank?.rankLevel === "chief_investigator" ? "Current Rank" : "Locked"}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Achievements Card */}
            <Card className="bg-sherlock-lightBg paper-bg border-0 shadow-md order-2 md:order-3 md:col-span-3">
              <CardHeader className="border-b border-sherlock-secondary/20 pb-3">
                <CardTitle className="font-playfair">Detective Achievements</CardTitle>
                <CardDescription className="font-special">
                  Notable accomplishments in your detective career
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <ScrollArea className="h-64 rounded">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {/* First Consultation */}
                    <div className={`p-4 rounded-lg border ${achievements?.some(a => a.name === "First Consultation") ? "bg-sherlock-secondary/10 border-sherlock-secondary" : "bg-gray-100 border-gray-300"}`}>
                      <div className="flex items-center">
                        <span className="text-3xl mr-3">🔍</span>
                        <div>
                          <h4 className="font-playfair font-bold">First Consultation</h4>
                          <p className="text-xs font-special">Completed your first conversation with Sherlock Holmes</p>
                        </div>
                      </div>
                      <div className="mt-2 text-right">
                        <Badge variant={achievements?.some(a => a.name === "First Consultation") ? "default" : "outline"}>
                          {achievements?.some(a => a.name === "First Consultation") ? "Unlocked" : "Locked"}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Mystery Solver */}
                    <div className={`p-4 rounded-lg border ${achievements?.some(a => a.name === "Mystery Solver") ? "bg-sherlock-secondary/10 border-sherlock-secondary" : "bg-gray-100 border-gray-300"}`}>
                      <div className="flex items-center">
                        <span className="text-3xl mr-3">🧩</span>
                        <div>
                          <h4 className="font-playfair font-bold">Mystery Solver</h4>
                          <p className="text-xs font-special">Successfully solved a mystery case</p>
                        </div>
                      </div>
                      <div className="mt-2 text-right">
                        <Badge variant={achievements?.some(a => a.name === "Mystery Solver") ? "default" : "outline"}>
                          {achievements?.some(a => a.name === "Mystery Solver") ? "Unlocked" : "Locked"}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Clue Master */}
                    <div className={`p-4 rounded-lg border ${achievements?.some(a => a.name === "Clue Master") ? "bg-sherlock-secondary/10 border-sherlock-secondary" : "bg-gray-100 border-gray-300"}`}>
                      <div className="flex items-center">
                        <span className="text-3xl mr-3">🔎</span>
                        <div>
                          <h4 className="font-playfair font-bold">Clue Master</h4>
                          <p className="text-xs font-special">Analyzed 5 distinct clues in your investigations</p>
                        </div>
                      </div>
                      <div className="mt-2 text-right">
                        <Badge variant={achievements?.some(a => a.name === "Clue Master") ? "default" : "outline"}>
                          {achievements?.some(a => a.name === "Clue Master") ? "Unlocked" : "Locked"}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Logical Thinker */}
                    <div className={`p-4 rounded-lg border ${achievements?.some(a => a.name === "Logical Thinker") ? "bg-sherlock-secondary/10 border-sherlock-secondary" : "bg-gray-100 border-gray-300"}`}>
                      <div className="flex items-center">
                        <span className="text-3xl mr-3">🧠</span>
                        <div>
                          <h4 className="font-playfair font-bold">Logical Thinker</h4>
                          <p className="text-xs font-special">Asked 10 logical deduction questions</p>
                        </div>
                      </div>
                      <div className="mt-2 text-right">
                        <Badge variant={achievements?.some(a => a.name === "Logical Thinker") ? "default" : "outline"}>
                          {achievements?.some(a => a.name === "Logical Thinker") ? "Unlocked" : "Locked"}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Elite Detective */}
                    <div className={`p-4 rounded-lg border ${achievements?.some(a => a.name === "Elite Detective") ? "bg-sherlock-secondary/10 border-sherlock-secondary" : "bg-gray-100 border-gray-300"}`}>
                      <div className="flex items-center">
                        <span className="text-3xl mr-3">🕵️</span>
                        <div>
                          <h4 className="font-playfair font-bold">Elite Detective</h4>
                          <p className="text-xs font-special">Reached the highest rank of Chief Investigator</p>
                        </div>
                      </div>
                      <div className="mt-2 text-right">
                        <Badge variant={achievements?.some(a => a.name === "Elite Detective") ? "default" : "outline"}>
                          {achievements?.some(a => a.name === "Elite Detective") ? "Unlocked" : "Locked"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              </CardContent>
              <CardFooter className="border-t border-sherlock-secondary/20 pt-4">
                <p className="text-xs font-special italic">
                  Continue solving cases and making deductions to unlock more achievements!
                </p>
              </CardFooter>
            </Card>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
}