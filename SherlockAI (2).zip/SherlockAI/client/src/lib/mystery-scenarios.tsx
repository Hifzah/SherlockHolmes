import React from 'react';
import { Activity, User, FileText } from "lucide-react";
import { MysteryScenario } from "./types";

// Generate a mystery scenario
export const getMysteryScenario = (): MysteryScenario => {
  return {
    prompt: "The body lies still on the parlor floor. What shall we examine first to advance our investigation?",
    options: [
      {
        id: "pulse",
        title: "Check the pulse",
        icon: <Activity className="w-12 h-12 text-sherlock-primary" />,
        response: "The victim has been deceased for approximately 6 hours, judging by the body temperature and lividity. The absence of struggle suggests familiarity with the assailant. Most revealing."
      },
      {
        id: "footprints",
        title: "Look for footprints",
        icon: <FileText className="w-12 h-12 text-sherlock-primary" />,
        response: "Observe these distinctive boot prints - size 11, made by an expensive Italian leather boot with a slight limp in the right step. Our culprit is a wealthy gentleman with an old injury."
      },
      {
        id: "witnesses",
        title: "Search for witnesses",
        icon: <User className="w-12 h-12 text-sherlock-primary" />,
        response: "The maid reports seeing a tall figure in a dark coat leaving through the garden gate at approximately 11 p.m. Most curiously, she noted the person was wearing gloves despite the warm evening."
      }
    ]
  };
};