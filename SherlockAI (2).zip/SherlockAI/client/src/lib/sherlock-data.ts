import { Message } from "./types";
import { getMysteryScenario } from "./mystery-scenarios";

// Initial greeting message
export const initialMessage: Message = {
  id: "initial",
  role: "assistant",
  content: "Good day. I am Sherlock Holmes—consulting detective. Should you require assistance, speak plainly. I abhor boredom, and nothing cures it better than a proper mystery. What matter requires my attention today?"
};

// List of Sherlock Holmes quotes
export const holmesQuotes = [
  "When you have eliminated the impossible, whatever remains, however improbable, must be the truth.",
  "I never guess. It is a shocking habit—destructive to the logical faculty.",
  "The world is full of obvious things which nobody by any chance ever observes.",
  "You see, but you do not observe. The distinction is clear.",
  "It is a capital mistake to theorize before one has data. Insensibly one begins to twist facts to suit theories, instead of theories to suit facts.",
  "I am a brain, Watson. The rest of me is a mere appendix.",
  "Education never ends, Watson. It is a series of lessons, with the greatest for the last.",
  "There is nothing more deceptive than an obvious fact.",
  "It has long been an axiom of mine that the little things are infinitely the most important.",
  "I cannot live without brain-work. What else is there to live for?"
];

// Get a random Holmes quote
export const getRandomQuote = (): string => {
  const randomIndex = Math.floor(Math.random() * holmesQuotes.length);
  return holmesQuotes[randomIndex];
};

// Export the mystery scenario function
export { getMysteryScenario };

// Sample responses for demonstration
export const sherlockResponses = {
  default: "Most intriguing. I shall need more information to form a proper deduction. What additional details can you provide?",
  greeting: "I see you are familiar with proper etiquette. However, I prefer to dispense with excessive pleasantries and focus on the matter at hand. What brings you to consult me?",
  mystery: "A promising case indeed. My mind rebels at stagnation, and this presents several points of interest. Let us examine the evidence systematically.",
  incorrect: "You see, but you do not observe. The distinction is clear. Consider the facts more carefully before drawing conclusions.",
  correct: "The game is afoot! Your deduction shows promise. Now, let us proceed to the next logical step in our investigation."
};

// Available cases
export const cases = [
  {
    id: "case1",
    title: "The Missing Heirloom",
    description: "A valuable family heirloom has been stolen from a locked room.",
    status: "open"
  },
  {
    id: "case2",
    title: "The Baker Street Burglary",
    description: "A series of strange thefts in the Baker Street area.",
    status: "in-progress"
  },
  {
    id: "case3",
    title: "The Strange Case of Dr. Watson",
    description: "Dr. Watson has been acting peculiarly after returning from a medical conference.",
    status: "open"
  }
];
