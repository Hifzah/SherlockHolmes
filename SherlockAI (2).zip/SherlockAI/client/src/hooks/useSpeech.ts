import { useState, useEffect, useCallback } from 'react';

interface SpeakOptions {
  onEnd?: () => void;
  rate?: number;
  pitch?: number;
  volume?: number;
}

export const useSpeech = () => {
  const [isSupported, setIsSupported] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [recognition, setRecognition] = useState<any>(null);
  
  // Check for browser support on mount
  useEffect(() => {
    const hasSpeechRecognition = 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
    const hasSpeechSynthesis = 'speechSynthesis' in window;
    setIsSupported(hasSpeechRecognition && hasSpeechSynthesis);
    
    if (hasSpeechRecognition) {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';
      
      recognitionInstance.onresult = (event: any) => {
        const result = event.results[0][0].transcript;
        setTranscript(result);
      };
      
      setRecognition(recognitionInstance);
    }
    
    // Cleanup
    return () => {
      if (recognition) {
        try {
          recognition.stop();
        } catch (e) {
          // Ignore errors when stopping
        }
      }
      
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);
  
  // Start listening for speech
  const startListening = useCallback(() => {
    if (recognition) {
      try {
        recognition.start();
        setTranscript("");
      } catch (error) {
        console.error("Error starting speech recognition:", error);
      }
    }
  }, [recognition]);
  
  // Stop listening
  const stopListening = useCallback(() => {
    if (recognition) {
      try {
        recognition.stop();
      } catch (error) {
        console.error("Error stopping speech recognition:", error);
      }
    }
  }, [recognition]);
  
  // Text-to-speech function
  const speak = useCallback((text: string, options: SpeakOptions = {}) => {
    if (!window.speechSynthesis) return;
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Configure voice settings
    utterance.rate = options.rate || 0.9;  // Slightly slower for dramatic effect
    utterance.pitch = options.pitch || 1.1; // Slightly higher pitch for authority
    utterance.volume = options.volume || 1;
    
    // Try to select a British male voice if available
    let voices = window.speechSynthesis.getVoices();
    
    if (voices.length === 0) {
      // If voices aren't loaded yet, wait and try again
      window.speechSynthesis.onvoiceschanged = () => {
        voices = window.speechSynthesis.getVoices();
        setVoice();
      };
    } else {
      setVoice();
    }
    
    function setVoice() {
      // Try to find a British male voice
      let selectedVoice = voices.find(voice => 
        voice.lang.includes('en-GB') && voice.name.toLowerCase().includes('male')
      );
      
      // Fallback to any British voice
      if (!selectedVoice) {
        selectedVoice = voices.find(voice => voice.lang.includes('en-GB'));
      }
      
      // Further fallback to any English voice
      if (!selectedVoice) {
        selectedVoice = voices.find(voice => voice.lang.includes('en'));
      }
      
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
    }
    
    if (options.onEnd) {
      utterance.onend = options.onEnd;
    }
    
    window.speechSynthesis.speak(utterance);
  }, []);
  
  // Cancel speech
  const cancel = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }, []);
  
  return {
    isSupported,
    transcript,
    startListening,
    stopListening,
    speak,
    cancel
  };
};
