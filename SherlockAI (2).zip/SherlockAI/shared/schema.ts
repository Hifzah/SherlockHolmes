import { pgTable, text, serial, integer, boolean, timestamp, uuid, unique, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Chat schema
export const chats = pgTable("chats", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertChatSchema = createInsertSchema(chats).pick({
  userId: true,
  title: true,
});

// Message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  chatId: uuid("chat_id").references(() => chats.id).notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  chatId: true,
  role: true,
  content: true,
});

// Case schema
export const cases = pgTable("cases", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("open"), // 'open', 'closed', 'in-progress'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCaseSchema = createInsertSchema(cases).pick({
  userId: true,
  title: true,
  description: true,
  status: true,
});

// User detective rank system
export const userRanks = pgTable("user_ranks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  guestId: text("guest_id").unique(), // For tracking non-logged-in users
  rankLevel: text("rank_level").notNull().default("newbie_detective"), // newbie_detective, inspector, chief_investigator
  rankPoints: integer("rank_points").notNull().default(0),
  questionsAsked: integer("questions_asked").notNull().default(0),
  logicalQuestionsAsked: integer("logical_questions").notNull().default(0),
  mysteriesSolved: integer("mysteries_solved").notNull().default(0),
  cluesAnalyzed: integer("clues_analyzed").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserRankSchema = createInsertSchema(userRanks).pick({
  userId: true,
  guestId: true,
  rankLevel: true,
});

// Detective achievements
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  badgeIcon: text("badge_icon").notNull(),
  pointsAwarded: integer("points_awarded").notNull().default(10),
  requiredRank: text("required_rank").notNull().default("newbie_detective"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  name: true,
  description: true,
  badgeIcon: true,
  pointsAwarded: true,
  requiredRank: true,
});

// Junction table for user achievements
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userRankId: integer("user_rank_id").references(() => userRanks.id).notNull(),
  achievementId: integer("achievement_id").references(() => achievements.id).notNull(),
  awardedAt: timestamp("awarded_at").defaultNow().notNull(),
}, (table) => ({
  userAchievementUnique: unique().on(table.userRankId, table.achievementId),
}));

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userRankId: true,
  achievementId: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertChat = z.infer<typeof insertChatSchema>;
export type Chat = typeof chats.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Case = typeof cases.$inferSelect;

export type InsertUserRank = z.infer<typeof insertUserRankSchema>;
export type UserRank = typeof userRanks.$inferSelect;

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;

// Note schema for Sherlock's Notebook
export const NOTE_TYPES = ["clue", "observation", "deduction", "warning"] as const;

export const notes = pgTable("notes", {
  id: uuid("id").primaryKey().defaultRandom(),
  chatId: uuid("chat_id").references(() => chats.id).notNull(),
  content: text("content").notNull(),
  type: text("type").notNull().$type<typeof NOTE_TYPES[number]>(),
  importance: integer("importance").notNull().default(1), // 1 = low, 2 = medium, 3 = high
  source: text("source").notNull().default("holmes"), // 'holmes' or 'user'
  relatedMessageId: integer("related_message_id").references(() => messages.id),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertNoteSchema = createInsertSchema(notes).pick({
  chatId: true,
  content: true,
  type: true,
  importance: true,
  source: true,
  relatedMessageId: true,
});

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;
