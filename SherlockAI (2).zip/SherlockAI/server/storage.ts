import { 
  users, chats, messages, userRanks, achievements, userAchievements, notes,
  type User, type InsertUser, type Chat, type InsertChat, type Message, type InsertMessage,
  type UserRank, type InsertUserRank, type Achievement, type UserAchievement, type InsertAchievement,
  type Note, type InsertNote
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Chat-related operations
  createChat(chat: InsertChat): Promise<Chat>;
  getChat(id: string): Promise<Chat | undefined>;
  getUserChats(userId: number | null): Promise<Chat[]>;
  
  // Message-related operations
  createMessage(message: InsertMessage): Promise<Message>;
  getChatMessages(chatId: string): Promise<Message[]>;
  
  // Detective rank system operations
  getUserRank(userId: number | null, guestId?: string): Promise<UserRank | undefined>;
  createUserRank(rank: InsertUserRank): Promise<UserRank>;
  updateUserRank(id: number, updates: Partial<UserRank>): Promise<UserRank>;
  
  // Achievement operations
  getAchievements(): Promise<Achievement[]>; 
  getUserAchievements(userRankId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  awardAchievement(userRankId: number, achievementId: number): Promise<UserAchievement>;
  
  // Sherlock's Notebook operations
  createNote(note: InsertNote): Promise<Note>;
  getChatNotes(chatId: string): Promise<Note[]>;
  getNote(id: string): Promise<Note | undefined>;
  deleteNote(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async createChat(chat: InsertChat): Promise<Chat> {
    const [newChat] = await db
      .insert(chats)
      .values(chat)
      .returning();
    return newChat;
  }
  
  async getChat(id: string): Promise<Chat | undefined> {
    const [chat] = await db
      .select()
      .from(chats)
      .where(eq(chats.id, id));
    return chat || undefined;
  }
  
  async getUserChats(userId: number | null): Promise<Chat[]> {
    // If userId is null, we're dealing with a guest user
    if (userId === null) {
      return []; // Guest users don't have saved chats
    }
    
    return await db
      .select()
      .from(chats)
      .where(eq(chats.userId, userId))
      .orderBy(desc(chats.updatedAt));
  }
  
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db
      .insert(messages)
      .values(message)
      .returning();
      
    // Update the chat's updatedAt timestamp
    await db
      .update(chats)
      .set({ updatedAt: new Date() })
      .where(eq(chats.id, message.chatId));
      
    return newMessage;
  }
  
  async getChatMessages(chatId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.chatId, chatId))
      .orderBy(messages.timestamp);
  }
  
  // Detective rank system operations
  async getUserRank(userId: number | null, guestId?: string): Promise<UserRank | undefined> {
    if (userId) {
      // Look up by user ID
      const [rank] = await db
        .select()
        .from(userRanks)
        .where(eq(userRanks.userId, userId));
      return rank;
    } else if (guestId) {
      // Look up by guest ID
      const [rank] = await db
        .select()
        .from(userRanks)
        .where(eq(userRanks.guestId, guestId));
      return rank;
    }
    return undefined;
  }
  
  async createUserRank(rank: InsertUserRank): Promise<UserRank> {
    const [newRank] = await db
      .insert(userRanks)
      .values(rank)
      .returning();
    return newRank;
  }
  
  async updateUserRank(id: number, updates: Partial<UserRank>): Promise<UserRank> {
    const [updatedRank] = await db
      .update(userRanks)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(userRanks.id, id))
      .returning();
    return updatedRank;
  }
  
  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements);
  }
  
  async getUserAchievements(userRankId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const results = await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userRankId, userRankId))
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id));
    
    // Format results to match expected return type
    return results.map(row => ({
      ...row.user_achievements,
      achievement: row.achievements
    }));
  }
  
  async awardAchievement(userRankId: number, achievementId: number): Promise<UserAchievement> {
    try {
      const [award] = await db
        .insert(userAchievements)
        .values({
          userRankId,
          achievementId
        })
        .returning();
      
      // Update the user's rank points
      const [achievement] = await db
        .select()
        .from(achievements)
        .where(eq(achievements.id, achievementId));
      
      if (achievement) {
        const [userRank] = await db
          .select()
          .from(userRanks)
          .where(eq(userRanks.id, userRankId));
        
        if (userRank) {
          await this.updateUserRank(userRankId, {
            rankPoints: userRank.rankPoints + achievement.pointsAwarded
          });
        }
      }
      
      return award;
    } catch (error) {
      // Achievement might already be awarded, which is fine
      console.log("Error awarding achievement:", error);
      
      // Return the existing award
      const existingAwards = await db
        .select()
        .from(userAchievements)
        .where(
          eq(userAchievements.userRankId, userRankId)
        );
      
      const existingAward = existingAwards.find(award => 
        award.achievementId === achievementId
      );
      
      if (existingAward) {
        return existingAward;
      }
      
      throw error;
    }
  }
}

// For in-memory storage fallback when database isn't configured
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chats: Map<string, Chat>;
  private messagesByChatId: Map<string, Message[]>;
  private userRanks: Map<number, UserRank>;
  private userRanksByGuestId: Map<string, UserRank>; 
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<number, UserAchievement[]>;
  currentId: number;
  currentRankId: number;
  currentAchievementId: number;
  currentUserAchievementId: number;

  constructor() {
    this.users = new Map();
    this.chats = new Map();
    this.messagesByChatId = new Map();
    this.userRanks = new Map();
    this.userRanksByGuestId = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.currentId = 1;
    this.currentRankId = 1;
    this.currentAchievementId = 1;
    this.currentUserAchievementId = 1;
    
    // Initialize with default achievements
    this.initializeAchievements();
  }
  
  private initializeAchievements() {
    const defaultAchievements: Achievement[] = [
      {
        id: this.currentAchievementId++,
        name: "First Consultation",
        description: "Completed your first conversation with Sherlock Holmes",
        badgeIcon: "🔍",
        pointsAwarded: 10,
        requiredRank: "newbie_detective",
        createdAt: new Date()
      },
      {
        id: this.currentAchievementId++,
        name: "Mystery Solver",
        description: "Successfully solved a mystery case",
        badgeIcon: "🧩",
        pointsAwarded: 25,
        requiredRank: "newbie_detective",
        createdAt: new Date()
      },
      {
        id: this.currentAchievementId++,
        name: "Clue Master",
        description: "Analyzed 5 distinct clues in your investigations",
        badgeIcon: "🔎",
        pointsAwarded: 15,
        requiredRank: "newbie_detective",
        createdAt: new Date()
      },
      {
        id: this.currentAchievementId++,
        name: "Logical Thinker",
        description: "Asked 10 logical deduction questions",
        badgeIcon: "🧠",
        pointsAwarded: 20,
        requiredRank: "inspector",
        createdAt: new Date()
      },
      {
        id: this.currentAchievementId++,
        name: "Elite Detective",
        description: "Reached the highest rank of Chief Investigator",
        badgeIcon: "🕵️",
        pointsAwarded: 50,
        requiredRank: "chief_investigator",
        createdAt: new Date()
      }
    ];
    
    defaultAchievements.forEach(achievement => {
      this.achievements.set(achievement.id, achievement);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async createChat(chat: InsertChat): Promise<Chat> {
    const id = crypto.randomUUID();
    const newChat: Chat = { 
      id, 
      title: chat.title || "New consultation",
      userId: chat.userId || null,
      createdAt: new Date(), 
      updatedAt: new Date() 
    };
    this.chats.set(id, newChat);
    return newChat;
  }
  
  async getChat(id: string): Promise<Chat | undefined> {
    return this.chats.get(id);
  }
  
  async getUserChats(userId: number | null): Promise<Chat[]> {
    // If userId is null, we're dealing with a guest user
    if (userId === null) {
      return []; // Guest users don't have saved chats
    }
    
    const userChats: Chat[] = [];
    // Convert iterator to array first to avoid TypeScript issues
    const chats = Array.from(this.chats.values());
    
    for (const chat of chats) {
      if (chat.userId === userId) {
        userChats.push(chat);
      }
    }
    // Sort by updatedAt
    return userChats.sort((a, b) => 
      b.updatedAt.getTime() - a.updatedAt.getTime()
    );
  }
  
  async createMessage(message: InsertMessage): Promise<Message> {
    const chatMessages = this.messagesByChatId.get(message.chatId) || [];
    
    const newMessage: Message = {
      ...message,
      id: chatMessages.length + 1,
      timestamp: new Date()
    };
    
    chatMessages.push(newMessage);
    this.messagesByChatId.set(message.chatId, chatMessages);
    
    // Update the chat's updatedAt timestamp
    const chat = this.chats.get(message.chatId);
    if (chat) {
      chat.updatedAt = new Date();
      this.chats.set(message.chatId, chat);
    }
    
    return newMessage;
  }
  
  async getChatMessages(chatId: string): Promise<Message[]> {
    return this.messagesByChatId.get(chatId) || [];
  }
  
  // Detective rank system operations
  async getUserRank(userId: number | null, guestId?: string): Promise<UserRank | undefined> {
    if (userId) {
      return this.userRanks.get(userId);
    } else if (guestId) {
      return this.userRanksByGuestId.get(guestId);
    }
    return undefined;
  }
  
  async createUserRank(rank: InsertUserRank): Promise<UserRank> {
    const id = this.currentRankId++;
    const newRank: UserRank = {
      id,
      userId: rank.userId || null,
      guestId: rank.guestId || null,
      rankLevel: rank.rankLevel || "newbie_detective",
      rankPoints: 0,
      questionsAsked: 0,
      logicalQuestionsAsked: 0,
      mysteriesSolved: 0,
      cluesAnalyzed: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    if (newRank.userId) {
      this.userRanks.set(newRank.userId, newRank);
    }
    
    if (newRank.guestId) {
      this.userRanksByGuestId.set(newRank.guestId, newRank);
    }
    
    return newRank;
  }
  
  async updateUserRank(id: number, updates: Partial<UserRank>): Promise<UserRank> {
    // Find the rank in either map
    let userRank: UserRank | undefined;
    
    // Try to find by ID in the userId map
    const userRanksValues = Array.from(this.userRanks.values());
    for (const rank of userRanksValues) {
      if (rank.id === id) {
        userRank = rank;
        break;
      }
    }
    
    // If not found, try in the guestId map
    if (!userRank) {
      const guestRanksValues = Array.from(this.userRanksByGuestId.values());
      for (const rank of guestRanksValues) {
        if (rank.id === id) {
          userRank = rank;
          break;
        }
      }
    }
    
    if (!userRank) {
      throw new Error(`User rank with ID ${id} not found`);
    }
    
    // Update the rank
    const updatedRank: UserRank = {
      ...userRank,
      ...updates,
      updatedAt: new Date()
    };
    
    // Update in both maps if necessary
    if (updatedRank.userId) {
      this.userRanks.set(updatedRank.userId, updatedRank);
    }
    
    if (updatedRank.guestId) {
      this.userRanksByGuestId.set(updatedRank.guestId, updatedRank);
    }
    
    return updatedRank;
  }
  
  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }
  
  async getUserAchievements(userRankId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievements = this.userAchievements.get(userRankId) || [];
    
    return userAchievements.map(ua => {
      const achievement = this.achievements.get(ua.achievementId);
      if (!achievement) {
        throw new Error(`Achievement with ID ${ua.achievementId} not found`);
      }
      
      return {
        ...ua,
        achievement
      };
    });
  }
  
  async awardAchievement(userRankId: number, achievementId: number): Promise<UserAchievement> {
    // Check if achievement already exists
    const existingAchievements = this.userAchievements.get(userRankId) || [];
    const existing = existingAchievements.find(ua => ua.achievementId === achievementId);
    
    if (existing) {
      return existing;
    }
    
    // Create a new achievement award
    const newAward: UserAchievement = {
      id: this.currentUserAchievementId++,
      userRankId,
      achievementId,
      awardedAt: new Date()
    };
    
    // Add to the user's achievements
    if (!this.userAchievements.has(userRankId)) {
      this.userAchievements.set(userRankId, []);
    }
    this.userAchievements.get(userRankId)!.push(newAward);
    
    // Update the user's rank points
    const achievement = this.achievements.get(achievementId);
    if (achievement) {
      // Find the user rank
      let userRank: UserRank | undefined;
      
      // Check in both maps
      const userRanksValues = Array.from(this.userRanks.values());
      for (const rank of userRanksValues) {
        if (rank.id === userRankId) {
          userRank = rank;
          break;
        }
      }
      
      if (!userRank) {
        const guestRanksValues = Array.from(this.userRanksByGuestId.values());
        for (const rank of guestRanksValues) {
          if (rank.id === userRankId) {
            userRank = rank;
            break;
          }
        }
      }
      
      if (userRank) {
        this.updateUserRank(userRankId, {
          rankPoints: userRank.rankPoints + achievement.pointsAwarded
        });
      }
    }
    
    return newAward;
  }
}

// Use database storage if DATABASE_URL is provided, otherwise use memory storage
export const storage = process.env.DATABASE_URL 
  ? new DatabaseStorage() 
  : new MemStorage();
